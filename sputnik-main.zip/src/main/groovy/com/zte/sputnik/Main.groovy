package com.zte.sputnik

class Main {
    public static void main(String[] args) {
        println 'hello'
    }
}
