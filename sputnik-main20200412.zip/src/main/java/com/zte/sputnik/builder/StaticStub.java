package com.zte.sputnik.builder;

public interface StaticStub<T> {
}
